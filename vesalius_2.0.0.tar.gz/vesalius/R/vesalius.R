#' vesalius
#' 
#' Vesalius: Spatial Omics analysis using images processing
#' 
#' @name vesalius_package
#' @aliases vesalius-package
#' 
#' @useDynLib vesalius
#' @importFrom Rcpp sourceCpp
"_PACKAGE"