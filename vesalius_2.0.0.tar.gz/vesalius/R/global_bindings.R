################################################################################
############################   ST package        ###############################
################################################################################

#----------------------------/Global bindings/---------------------------------#
utils::globalVariables(c(".", "barcodes", "cc",
  "cc.y", "cluster", "p.value", "seurat_clusters",
  "territories", "territorries", "territory",
  "tile", "tmpImg", "value", "x", "y", "img", "p_value_adj",
  "ind1", "ind2", "origin", "trial", "vesalius"))
