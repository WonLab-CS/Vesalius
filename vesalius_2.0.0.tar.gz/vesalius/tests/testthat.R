library(testthat)
library(vesalius)

test_check("vesalius")
